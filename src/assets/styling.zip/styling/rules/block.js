module.exports = {
  'block-closing-brace-empty-line-before': 'never',
  'block-closing-brace-newline-after': 'always',
  'block-closing-brace-newline-before': 'always',
  'block-no-empty': true,
  'block-opening-brace-newline-after': 'always',
  'block-opening-brace-space-before': 'always'
};