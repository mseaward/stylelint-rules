module.exports = {
  'color-hex-case': 'lower',
  'color-hex-length': 'long',
  'color-no-invalid-hex': true
};