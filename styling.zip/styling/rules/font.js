module.exports = {
  'font-family-no-duplicate-names': true,
  'font-weight-notation': 'numeric',
  'font-family-no-missing-generic-family-keyword': true,
  'font-family-name-quotes': 'always-unless-keyword'
};